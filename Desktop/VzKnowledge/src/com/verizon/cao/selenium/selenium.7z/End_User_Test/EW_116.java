package com.verizon.cao.selenium.End_User_Test;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.verizon.cao.selenium.End_User_Page.MiddlePage;
import com.verizon.cao.selenium.common.CommonFunctions;
import com.verizon.cao.selenium.common.Constants;
import com.verizon.cao.selenium.common.Ext_Report;
import com.verizon.cao.selenium.common.Log;
import com.verizon.cao.selenium.common.SignInPage;
import com.verizon.cao.selenium.common.ObjectRepository.EndUser;
import com.verizon.cao.selenium.setup.SetupBase;

public class EW_116 extends SetupBase implements Constants{
	
	private ExtentReports extent;
	private ExtentTest test;
CommonFunctions cmf = new CommonFunctions();
	
	private Object baseurl;
	MiddlePage midpage = new MiddlePage();
	public EW_116() throws Exception {
		super();
	}
	
	@BeforeMethod
	
	public  void setUp()throws Exception {
		DOMConfigurator.configure("log4j.xml");
		Log.startTestCase("NetworkBG_Profile_page");
		Log.info("BeforeClass Method Invoked");
		extent = Ext_Report.Instance("End_User");
		/*baseurl = super.getTestBaseUrl();
		System.out.println("inside before class"  +baseurl);*/
}
	@Test
	public void profile_page(){
		test = extent.startTest("NetworkBG_Profile_page");
		Log.info("VzKnowledge Login Invoked");
		WebDriver driver = CommonFunctions.driver;
		if (! CommonFunctions.executeTestCase){
			test.log(LogStatus.SKIP, "Skipping the test case as error encountered during login.", "Usage: <span style='font-weight:bold;'>Skipped test cases.</span> Login Existing User.");
			throw new SkipException("Skipping the test case as error encountered during login.");			
		}
		/*SignInPage.UserID(driver, extent, test).sendKeys(Username);
		SignInPage.Password(driver, extent, test).sendKeys(Password);
		SignInPage.btn_SignOn(driver, extent, test).click();
		cmf.alert(driver);
		cmf.Processing(driver);*/
		cmf.sleep(3000);
		String chk_profile_name = driver.findElement(By.xpath(EndUser.profile_name)).getText();
		cmf.clkElement(driver, EndUser.profile_name, "Profile", extent, test);
		//driver.findElement(By.xpath(EndUser.profile_name)).click();
		cmf.sleep(1000);
		if (chk_profile_name.contains(driver.findElement(By.xpath(EndUser.profile_chk_name)).getText())){
			System.out.println("Profile name matched");
			Log.info("Profile name matched");
			test.log(LogStatus.PASS, "Profile Name", "Profile name matched");
		}
		if (cmf.existsElement(EndUser.myprofile_chk, driver) == true){
			System.out.println("My Profile link is Exists");
			Log.info("My Profile link is Exists");
			test.log(LogStatus.PASS, "My Profile", "My Profile link is Exists");
		}
		
		if (cmf.existsElement(EndUser.profile_signout, driver) == true){
			System.out.println("Sign Out link is Exists");
			Log.info("Sign Out link is Exists");
			test.log(LogStatus.PASS, "Sign Out", "Sign Out link is Exists");
		}
	}
	@AfterMethod
	public void teardown() {
		Log.info("VzKnowledge - AfterClass() method invoked...");
//		cmf.VzLogout(driver);
		extent.endTest(test);
		extent.flush();
	}
}
